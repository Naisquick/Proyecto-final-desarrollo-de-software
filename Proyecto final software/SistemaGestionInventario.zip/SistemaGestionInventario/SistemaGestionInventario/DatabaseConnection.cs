﻿using System;
using System.Data.SqlClient;
using System.Configuration;

namespace TuNamespace
{
    public class DatabaseConnection
    {
        private SqlConnection connection;

        // Constructor - Lee la cadena de conexión desde el archivo de configuración
        public DatabaseConnection()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["InventarioDB"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }

        // Método para abrir la conexión
        public void OpenConnection()
        {
            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                {
                    connection.Open();
                    Console.WriteLine("Conexión abierta.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al abrir la conexión: " + ex.Message);
            }
        }

        // Método para cerrar la conexión
        public void CloseConnection()
        {
            try
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                    Console.WriteLine("Conexión cerrada.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al cerrar la conexión: " + ex.Message);
            }
        }

        // Método para obtener la conexión
        public SqlConnection GetConnection()
        {
            return connection;
        }
    }
}

﻿namespace SistemaGestionInventario.Vistas
{
    partial class GestionProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnAgregarProducto = new Button();
            btnEliminarProducto = new Button();
            btnEditarProducto = new Button();
            DataGridViewProductos = new DataGridView();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtNombreProducto = new TextBox();
            txtPrecioProducto = new TextBox();
            txtCantidadProducto = new TextBox();
            cbCategoriaProducto = new ComboBox();
            cbProveedorProducto = new ComboBox();
            txtCodigoProducto = new TextBox();
            ((System.ComponentModel.ISupportInitialize)DataGridViewProductos).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(270, 5);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 0;
            label1.Text = "Nombre";
            // 
            // btnAgregarProducto
            // 
            btnAgregarProducto.Location = new Point(226, 385);
            btnAgregarProducto.Name = "btnAgregarProducto";
            btnAgregarProducto.Size = new Size(125, 23);
            btnAgregarProducto.TabIndex = 1;
            btnAgregarProducto.Text = "Agregar";
            btnAgregarProducto.UseVisualStyleBackColor = true;
            btnAgregarProducto.Click += btnAgregarProducto_Click;
            // 
            // btnEliminarProducto
            // 
            btnEliminarProducto.Location = new Point(382, 385);
            btnEliminarProducto.Name = "btnEliminarProducto";
            btnEliminarProducto.Size = new Size(125, 23);
            btnEliminarProducto.TabIndex = 3;
            btnEliminarProducto.Text = "Eliminar";
            btnEliminarProducto.UseVisualStyleBackColor = true;
            btnEliminarProducto.Click += btnEliminarProducto_Click;
            // 
            // btnEditarProducto
            // 
            btnEditarProducto.Location = new Point(543, 385);
            btnEditarProducto.Name = "btnEditarProducto";
            btnEditarProducto.Size = new Size(125, 23);
            btnEditarProducto.TabIndex = 4;
            btnEditarProducto.Text = "Editar";
            btnEditarProducto.UseVisualStyleBackColor = true;
            btnEditarProducto.Click += btnEditarProducto_Click;
            // 
            // DataGridViewProductos
            // 
            DataGridViewProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridViewProductos.Location = new Point(98, 208);
            DataGridViewProductos.Name = "DataGridViewProductos";
            DataGridViewProductos.Size = new Size(712, 171);
            DataGridViewProductos.TabIndex = 7;
            DataGridViewProductos.CellContentClick += dataGridViewProductos_CellContentClick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(393, 5);
            label2.Name = "label2";
            label2.Size = new Size(114, 15);
            label2.TabIndex = 8;
            label2.Text = "Codigo de producto";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(537, 5);
            label3.Name = "label3";
            label3.Size = new Size(58, 15);
            label3.TabIndex = 9;
            label3.Text = "Categoria";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(270, 125);
            label4.Name = "label4";
            label4.Size = new Size(40, 15);
            label4.TabIndex = 10;
            label4.Text = "Precio";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(393, 125);
            label5.Name = "label5";
            label5.Size = new Size(59, 15);
            label5.TabIndex = 11;
            label5.Text = "Existencia";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(534, 125);
            label6.Name = "label6";
            label6.Size = new Size(61, 15);
            label6.TabIndex = 12;
            label6.Text = "Proveedor";
            // 
            // txtNombreProducto
            // 
            txtNombreProducto.Location = new Point(270, 35);
            txtNombreProducto.Name = "txtNombreProducto";
            txtNombreProducto.Size = new Size(100, 23);
            txtNombreProducto.TabIndex = 14;
            // 
            // txtPrecioProducto
            // 
            txtPrecioProducto.Location = new Point(270, 152);
            txtPrecioProducto.Name = "txtPrecioProducto";
            txtPrecioProducto.Size = new Size(100, 23);
            txtPrecioProducto.TabIndex = 17;
            // 
            // txtCantidadProducto
            // 
            txtCantidadProducto.Location = new Point(393, 152);
            txtCantidadProducto.Name = "txtCantidadProducto";
            txtCantidadProducto.Size = new Size(100, 23);
            txtCantidadProducto.TabIndex = 18;
            // 
            // cbCategoriaProducto
            // 
            cbCategoriaProducto.FormattingEnabled = true;
            cbCategoriaProducto.Location = new Point(516, 35);
            cbCategoriaProducto.Name = "cbCategoriaProducto";
            cbCategoriaProducto.Size = new Size(121, 23);
            cbCategoriaProducto.TabIndex = 19;
            // 
            // cbProveedorProducto
            // 
            cbProveedorProducto.FormattingEnabled = true;
            cbProveedorProducto.Location = new Point(516, 152);
            cbProveedorProducto.Name = "cbProveedorProducto";
            cbProveedorProducto.Size = new Size(121, 23);
            cbProveedorProducto.TabIndex = 20;
            // 
            // label7
            // 
        
            // 
            // txtCodigoProducto
            // 
            txtCodigoProducto.Location = new Point(393, 35);
            txtCodigoProducto.Name = "txtCodigoProducto";
            txtCodigoProducto.Size = new Size(100, 23);
            txtCodigoProducto.TabIndex = 15;
            // 
            // GestionProductos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(850, 450);
            Controls.Add(cbProveedorProducto);
            Controls.Add(cbCategoriaProducto);
            Controls.Add(txtCantidadProducto);
            Controls.Add(txtPrecioProducto);
            Controls.Add(txtCodigoProducto);
            Controls.Add(txtNombreProducto);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(DataGridViewProductos);
            Controls.Add(btnEditarProducto);
            Controls.Add(btnEliminarProducto);
            Controls.Add(btnAgregarProducto);
            Controls.Add(label1);
            Name = "GestionProductos";
            Text = "GestionProductos";
            Load += GestionProductos_Load;
            ((System.ComponentModel.ISupportInitialize)DataGridViewProductos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnAgregarProducto;
        private Button btnEliminarProducto;
        private Button btnEditarProducto;
        private DataGridView DataGridViewProductos;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtNombreProducto;
        private TextBox txtPrecioProducto;
        private TextBox txtCantidadProducto;
        private ComboBox cbCategoriaProducto;
        private ComboBox cbProveedorProducto;
        private TextBox label7;
        private TextBox txtCodigoProducto;
    }
}
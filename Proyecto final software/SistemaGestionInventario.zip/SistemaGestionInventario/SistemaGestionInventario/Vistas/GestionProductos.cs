﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using TuNamespace;
using SistemaGestionInventario.Modelos;

namespace SistemaGestionInventario.Vistas
{
    public partial class GestionProductos : Form
    {
        public GestionProductos()
        {
            InitializeComponent();
            DataGridViewProductos.SelectionChanged += DataGridViewProductos_SelectionChanged;
            CargarProductos();

        }

        public class ComboBoxItem
        {
            public string Text { get; set; }
            public int Value { get; set; }


            public override string ToString()
            {
                return Text; // Esto es lo que se mostrará en el ComboBox
            }
        }

        private void CargarCategorias()
        {
            using (SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("SELECT IdCategoria, Nombre FROM Categorias", connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    cbCategoriaProducto.Items.Add(new ComboBoxItem
                    {
                        Text = reader["Nombre"].ToString(),
                        Value = Convert.ToInt32(reader["IdCategoria"])
                    });
                }
                reader.Close();
            }
        }

        private void CargarProveedores()
        {
            using (SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("SELECT IdProveedor, Nombre FROM Proveedores", connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    cbProveedorProducto.Items.Add(new ComboBoxItem
                    {
                        Text = reader["Nombre"].ToString(),
                        Value = Convert.ToInt32(reader["IdProveedor"])
                    });
                }
                reader.Close();
            }
        }



        private void CargarProductos()
        {

            try
            {
                // Verifica si las columnas ya fueron agregadas, si no, agrégalas
                if (DataGridViewProductos.Columns.Count == 0)
                {
                    DataGridViewProductos.Columns.Add("IdProducto", "IdProducto");
                    DataGridViewProductos.Columns.Add("Nombre", "Nombre");
                    DataGridViewProductos.Columns.Add("Precio", "Precio");
                    DataGridViewProductos.Columns.Add("Stock", "Stock");
                    DataGridViewProductos.Columns.Add("Categoria", "Categoría");
                    DataGridViewProductos.Columns.Add("Proveedor", "Proveedor");
                }

                // Abre la conexión
                using (SqlConnection conn = new SqlConnection("Server = localhost\\SQLEXPRESS; Database = InventarioDB; Trusted_Connection = True;"))
                {
                    conn.Open();

                    // Consulta SQL para obtener todos los productos con los nombres de categorías y proveedores
                    string query = "SELECT p.IdProducto, p.Nombre, p.Precio, p.Stock, c.Nombre AS Categoria, pr.Nombre AS Proveedor " +
                            "FROM Productos p " +
                            "INNER JOIN Categorias c ON p.IdCategoria = c.IdCategoria " +
                            "INNER JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Limpiar el DataGridView antes de agregar nuevos datos
                            DataGridViewProductos.Rows.Clear();

                            // Leer los datos y agregarlos al DataGridView
                            while (reader.Read())
                            {
                                // Agregar las filas con los valores obtenidos
                                DataGridViewProductos.Rows.Add(
                                    reader["IdProducto"].ToString(),
                                    reader["Nombre"].ToString(),
                                    reader["Precio"].ToString(),
                                    reader["Stock"].ToString(),
                                    reader["Categoria"].ToString(), // Nombre de la categoría
                                    reader["Proveedor"].ToString() // Nombre del proveedor
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar productos: " + ex.Message);
            }

            //string query = "SELECT p.IdProducto, p.Nombre, p.Precio, p.Stock, c.Nombre AS Categoria, pr.Nombre AS Proveedor " +
            //        "FROM Productos p " +
            //        "INNER JOIN Categorias c ON p.IdCategoria = c.IdCategoria " +
            //        "INNER JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor";

            //using (SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            //{
            //    SqlCommand command = new SqlCommand(query, connection);
            //    try
            //    {
            //        connection.Open();
            //        SqlDataReader reader = command.ExecuteReader();

            //        DataTable dt = new DataTable();
            //        dt.Load(reader);

            //        // Limpiar el DataGridView antes de llenar
            //        DataGridViewProductos.DataSource = null;
            //        DataGridViewProductos.Columns.Clear();

            //        // Llenar el DataGridView
            //        DataGridViewProductos.AutoGenerateColumns = false; // No generar automáticamente las columnas
            //        DataGridViewProductos.Columns.Add("IdProducto", "ID Producto");
            //        DataGridViewProductos.Columns.Add("Nombre", "Nombre");
            //        DataGridViewProductos.Columns.Add("Precio", "Precio");
            //        DataGridViewProductos.Columns.Add("Stock", "Stock");
            //        DataGridViewProductos.Columns.Add("Categoria", "Categoria");
            //        DataGridViewProductos.Columns.Add("Proveedor", "Proveedor");

            //        // Asigna los datos al DataGridView
            //        DataGridViewProductos.DataSource = dt;
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show($"Error al cargar productos: {ex.Message}");
            //    }
            //}
        }



        private void GestionProductos_Load(object sender, EventArgs e)
        {

            CargarCategorias();
            CargarProveedores();
            CargarProductos();


        }




        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            // Verificar que todos los campos estén llenos
            if (string.IsNullOrWhiteSpace(txtNombreProducto.Text) ||
                //string.IsNullOrWhiteSpace(txtDescripcionProducto.Text) ||
                cbCategoriaProducto.SelectedItem == null ||
                cbProveedorProducto.SelectedItem == null)
            {
                MessageBox.Show("Por favor, llena todos los campos.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Obtener los valores de los campos
            string nombre = txtNombreProducto.Text;
            // string descripcion = txtDescripcionProducto.Text;
            int categoriaId = ((ComboBoxItem)cbCategoriaProducto.SelectedItem).Value;
            int proveedorId = ((ComboBoxItem)cbProveedorProducto.SelectedItem).Value;
            decimal precio = decimal.Parse(txtPrecioProducto.Text);
            int stock = int.Parse(txtCantidadProducto.Text);



            // Crear la conexión y el comando
            using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {

                string query = "INSERT INTO Productos (Nombre, Precio, Stock, IdCategoria, IdProveedor) VALUES (@Nombre, @Precio, @Stock, @CategoriaId, @ProveedorId)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Asigna los parámetros
                    cmd.Parameters.AddWithValue("@Nombre", txtNombreProducto.Text);
                    cmd.Parameters.AddWithValue("@Precio", decimal.Parse(txtPrecioProducto.Text));
                    cmd.Parameters.AddWithValue("@Stock", int.Parse(txtCantidadProducto.Text));

                    // Aquí asegúrate de que los ComboBox están bien configurados
                    // y obtén los valores correctos de los ComboBox
                    cmd.Parameters.AddWithValue("@CategoriaId", ((ComboBoxItem)cbCategoriaProducto.SelectedItem).Value);
                    cmd.Parameters.AddWithValue("@ProveedorId", ((ComboBoxItem)cbProveedorProducto.SelectedItem).Value);

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Producto agregado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Llamar a CargarProductos() para actualizar la lista
                        CargarProductos();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al agregar el producto: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

        }

        private int idProductoSeleccionado; // Variable para almacenar el ID del producto seleccionado


        private void btnEditarProducto_Click(object sender, EventArgs e)
        {

            // Verifica que los campos no estén vacíos
            if (string.IsNullOrEmpty(txtNombreProducto.Text) || string.IsNullOrEmpty(txtPrecioProducto.Text) ||
                string.IsNullOrEmpty(txtCantidadProducto.Text) || cbCategoriaProducto.SelectedItem == null || cbProveedorProducto.SelectedItem == null)
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            // Obtiene el ID de la categoría y el proveedor seleccionados
            int idCategoria = ((ComboBoxItem)cbCategoriaProducto.SelectedItem).Value;
            int idProveedor = ((ComboBoxItem)cbProveedorProducto.SelectedItem).Value;
            idProductoSeleccionado = Convert.ToInt32(DataGridViewProductos.SelectedRows[0].Cells["IdProducto"].Value);

            string query = "UPDATE Productos SET Nombre = @Nombre, Precio = @Precio, Stock = @Stock, IdCategoria = @IdCategoria, IdProveedor = @IdProveedor WHERE IdProducto = @IdProducto";

            using (SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nombre", txtNombreProducto.Text);
                command.Parameters.AddWithValue("@Precio", decimal.Parse(txtPrecioProducto.Text));
                command.Parameters.AddWithValue("@Stock", int.Parse(txtCantidadProducto.Text));
                command.Parameters.AddWithValue("@IdCategoria", idCategoria);
                command.Parameters.AddWithValue("@IdProveedor", idProveedor);
                command.Parameters.AddWithValue("@IdProducto", idProductoSeleccionado);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Producto actualizado correctamente.");
                    CargarProductos(); // Vuelve a cargar los productos para reflejar los cambios.
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al actualizar el producto: {ex.Message}");
                }
            }

            //// Validar que todos los campos estén llenos
            //if (string.IsNullOrWhiteSpace(txtCodigoProducto.Text) ||
            //    string.IsNullOrWhiteSpace(txtNombreProducto.Text) ||
            //    string.IsNullOrWhiteSpace(txtPrecioProducto.Text) ||
            //    string.IsNullOrWhiteSpace(txtCantidadProducto.Text) ||
            //    cbCategoriaProducto.SelectedValue == null ||
            //    cbProveedorProducto.SelectedValue == null)
            //{
            //    MessageBox.Show("Por favor llena todos los campos.");
            //    return;
            //}

            //// Obtener los valores de los controles
            //int idProducto = Convert.ToInt32(txtCodigoProducto.Text);
            //    string nombre = txtNombreProducto.Text;
            //    decimal precio = Convert.ToDecimal(txtPrecioProducto.Text);
            //    int stock = Convert.ToInt32(txtCantidadProducto.Text);
            //    int idCategoria = Convert.ToInt32(cbCategoriaProducto.SelectedValue);
            //    int idProveedor = Convert.ToInt32(cbProveedorProducto.SelectedValue);

            //    // Consulta SQL para actualizar el producto
            //    string query = "UPDATE Productos SET Nombre = @Nombre, Precio = @Precio, Stock = @Stock, IdCategoria = @IdCategoria, IdProveedor = @IdProveedor WHERE IdProducto = @IdProducto";

            //    using (SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            //    {
            //        using (SqlCommand command = new SqlCommand(query, connection))
            //        {
            //            command.Parameters.AddWithValue("@IdProducto", idProducto);
            //            command.Parameters.AddWithValue("@Nombre", nombre);
            //            command.Parameters.AddWithValue("@Precio", precio);
            //            command.Parameters.AddWithValue("@Stock", stock);
            //            command.Parameters.AddWithValue("@IdCategoria", idCategoria);
            //            command.Parameters.AddWithValue("@IdProveedor", idProveedor);

            //            try
            //            {
            //                connection.Open();
            //                int filasAfectadas = command.ExecuteNonQuery();
            //                if (filasAfectadas > 0)
            //                {
            //                    MessageBox.Show("Producto actualizado exitosamente.");
            //                }
            //                else
            //                {
            //                    MessageBox.Show("No se pudo actualizar el producto. Verifique que el ID sea correcto.");
            //                }
            //            }
            //            catch (Exception ex)
            //            {
            //                MessageBox.Show("Error al actualizar el producto: " + ex.Message);
            //            }
            //        }
            //}

            // Recargar los productos en el DataGridView
            //    CargarProductos();


            // if (string.IsNullOrWhiteSpace(txtNombreProducto.Text) ||
            //     string.IsNullOrWhiteSpace(txtPrecioProducto.Text) ||
            //     string.IsNullOrWhiteSpace(txtCantidadProducto.Text) ||
            //     string.IsNullOrWhiteSpace(txtCategoria.Text) ||
            //     string.IsNullOrWhiteSpace(txtProveedor.Text))
            // {
            //     MessageBox.Show("Por favor llena todos los campos.");
            //     return;
            // }

            // int idProducto = Convert.ToInt32(dgvProductos.SelectedRows[0].Cells["IdProducto"].Value);

            // // Llama a los métodos para obtener los IDs correspondientes
            // int idCategoria = ObtenerIdCategoria(txtCategoria.Text);
            // int idProveedor = ObtenerIdProveedor(txtProveedor.Text);

            // if (idCategoria == 0 || idProveedor == 0)
            // {
            //     MessageBox.Show("La categoría o el proveedor seleccionados no son válidos.");
            //     return;
            // }

            // string query = "UPDATE Productos SET Nombre = @Nombre, Precio = @Precio, Stock = @Stock, IdCategoria = @IdCategoria, IdProveedor = @IdProveedor WHERE IdProducto = @IdProducto";

            // using (SqlConnection connection = new SqlConnection("tu_cadena_de_conexion_aqui"))
            // {
            //     SqlCommand command = new SqlCommand(query, connection);
            //     command.Parameters.AddWithValue("@Nombre", txtNombre.Text);
            //     command.Parameters.AddWithValue("@Precio", Convert.ToDecimal(txtPrecio.Text));
            //     command.Parameters.AddWithValue("@Stock", Convert.ToInt32(txtStock.Text));
            //     command.Parameters.AddWithValue("@IdCategoria", idCategoria);
            //     command.Parameters.AddWithValue("@IdProveedor", idProveedor);
            //     command.Parameters.AddWithValue("@IdProducto", idProducto);

            //     try
            //     {
            //         connection.Open();
            //         command.ExecuteNonQuery();
            //         MessageBox.Show("Producto actualizado correctamente.");
            //         CargarProductos(); // Refresca los datos del DataGridView
            //     }
            //     catch (Exception ex)
            //     {
            //         MessageBox.Show("Error al actualizar el producto: " + ex.Message);
            //     }
            //}




        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {

            // Verifica si el ID del producto ha sido proporcionado
            if (string.IsNullOrEmpty(txtCodigoProducto.Text))
            {
                MessageBox.Show("Por favor, selecciona un producto para eliminar.");
                return;
            }

            int productoId = int.Parse(txtCodigoProducto.Text);

            using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                conn.Open();
                string query = "DELETE FROM Productos WHERE IdProducto = @IdProducto";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@IdProducto", productoId);

                    try
                    {
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Producto eliminado correctamente.");
                            // Llama al método para cargar nuevamente los productos en el DataGridView
                            CargarProductos();
                        }
                        else
                        {
                            MessageBox.Show("No se encontró el producto para eliminar.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al eliminar el producto: " + ex.Message);
                    }
                }
            }


        }

        private void dataGridViewProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void DataGridViewProductos_SelectionChanged(object sender, EventArgs e)
        {
            if (DataGridViewProductos.CurrentRow != null)
            {
                // Asegúrate de que "IdProducto" sea el nombre correcto de la columna en tu DataGridView
                txtCodigoProducto.Text = DataGridViewProductos.CurrentRow.Cells["IdProducto"].Value.ToString();

                // También puedes llenar otros campos si lo deseas
                txtNombreProducto.Text = DataGridViewProductos.CurrentRow.Cells["Nombre"].Value.ToString();
                txtPrecioProducto.Text = DataGridViewProductos.CurrentRow.Cells["Precio"].Value.ToString();
                txtCantidadProducto.Text = DataGridViewProductos.CurrentRow.Cells["Stock"].Value.ToString();
            }

        }
        private void label7_Click(object sender, EventArgs e)
        {

        }
    }

}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaGestionInventario.Vistas
{
    public partial class GestionProveedores : Form
    {
        public GestionProveedores()
        {
            InitializeComponent();
            CargarProveedores();
            // Vincular el evento SelectionChanged al método manejador
            this.dataGridViewProveedores.SelectionChanged += new EventHandler(dataGridViewProveedores_SelectionChanged);


        }

        private void CargarProveedores()
        {
            using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                conn.Open();
                string query = "SELECT * FROM Proveedores";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridViewProveedores.DataSource = dt;
            }
        }


        private void GestionProveedores_Load(object sender, EventArgs e)
        {
            CargarProveedores();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombreEmpresa = txtNombreEmpresa.Text.Trim();
            string contacto = txtContacto.Text.Trim();
            string direccion = txtDireccion.Text.Trim();
            string telefono = txtTelefono.Text.Trim();

            if (string.IsNullOrWhiteSpace(nombreEmpresa) || string.IsNullOrWhiteSpace(contacto) ||
                string.IsNullOrWhiteSpace(direccion) || string.IsNullOrWhiteSpace(telefono))
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                conn.Open();
                string query = "INSERT INTO Proveedores (Nombre, Correo, Direccion, Telefono) VALUES (@NombreEmpresa, @Contacto, @Direccion, @Telefono)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@NombreEmpresa", nombreEmpresa);
                    cmd.Parameters.AddWithValue("@Contacto", contacto);
                    cmd.Parameters.AddWithValue("@Direccion", direccion);
                    cmd.Parameters.AddWithValue("@Telefono", telefono);
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Proveedor agregado correctamente.");
            txtNombreEmpresa.Clear();
            txtContacto.Clear();
            txtDireccion.Clear();
            txtTelefono.Clear();
            CargarProveedores(); // Recarga los proveedores en el DataGridView

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridViewProveedores.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor selecciona un proveedor para eliminar.");
                return;
            }

            // Obtén el ID del proveedor seleccionado (asumiendo que la primera columna es el ID)
            int proveedorId = Convert.ToInt32(dataGridViewProveedores.SelectedRows[0].Cells["IdProveedor"].Value);

            using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                conn.Open();
                string query = "DELETE FROM Proveedores WHERE IdProveedor = @Id";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", proveedorId);
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Proveedor eliminado correctamente.");
            CargarProveedores(); // Recarga los proveedores en el DataGridView
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombreEmpresa.Text) ||
        string.IsNullOrWhiteSpace(txtContacto.Text) ||
        string.IsNullOrWhiteSpace(txtDireccion.Text) ||
        string.IsNullOrWhiteSpace(txtTelefono.Text))
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            // Obtén el ID del proveedor seleccionado (asumiendo que la primera columna es el ID)
            int proveedorId = Convert.ToInt32(dataGridViewProveedores.SelectedRows[0].Cells["IdProveedor"].Value);

            using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                conn.Open();
                string query = "UPDATE Proveedores SET Nombre = @NombreEmpresa, Correo = @Contacto, Direccion = @Direccion, Telefono = @Telefono WHERE IdProveedor = @Id";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", proveedorId);
                    cmd.Parameters.AddWithValue("@NombreEmpresa", txtNombreEmpresa.Text);
                    cmd.Parameters.AddWithValue("@Contacto", txtContacto.Text);
                    cmd.Parameters.AddWithValue("@Direccion", txtDireccion.Text);
                    cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text);
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Proveedor actualizado correctamente.");
            CargarProveedores(); // Recarga los proveedores en el DataGridView
        }

        private void dataGridViewProveedores_SelectionChanged(object sender, EventArgs e)
        {
            // Verifica que hay filas seleccionadas
            if (dataGridViewProveedores.SelectedRows.Count > 0)
            {
                // Obtiene la fila seleccionada
                DataGridViewRow row = dataGridViewProveedores.SelectedRows[0];

                // Llena los TextBoxes con la información del proveedor seleccionado
                txtNombreEmpresa.Text = row.Cells["Nombre"].Value.ToString();
                txtContacto.Text = row.Cells["Correo"].Value.ToString();
                txtDireccion.Text = row.Cells["Direccion"].Value.ToString();
                txtTelefono.Text = row.Cells["Telefono"].Value.ToString();
            }
        }



    }
}

﻿using Google.Protobuf.WellKnownTypes;
using SistemaGestionInventario.Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static SistemaGestionInventario.Vistas.GestionProductos;

namespace SistemaGestionInventario.Vistas
{
    public partial class Consultar_Reportes : Form
    {
        public Consultar_Reportes()
        {
            InitializeComponent();
            CargarProductos();  // Llamar al método al abrir el formulario

        }

        // Método para cargar todos los productos en el DataGridView
        private void CargarProductos()
        {
            try
            {
                // Verifica si las columnas ya fueron agregadas, si no, agrégalas
                if (dataGridViewProductos.Columns.Count == 0)
                {
                    dataGridViewProductos.Columns.Add("IdProducto", "ID Producto"); // Agregar columna para ID del producto
                    dataGridViewProductos.Columns.Add("Nombre", "Nombre");
                    dataGridViewProductos.Columns.Add("Precio", "Precio");
                    dataGridViewProductos.Columns.Add("Stock", "Stock");
                    dataGridViewProductos.Columns.Add("Categoria", "Categoría");
                    dataGridViewProductos.Columns.Add("Proveedor", "Proveedor");
                }

                // Abre la conexión
                using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
                {
                    conn.Open();

                    // Consulta SQL para obtener todos los productos con los nombres de categorías y proveedores
                    string query = @"
            SELECT p.IdProducto, p.Nombre, p.Precio, p.Stock, c.Nombre AS Categoria, pr.Nombre AS Proveedor 
            FROM Productos p
            INNER JOIN Categorias c ON p.IdCategoria = c.IdCategoria
            INNER JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Limpiar el DataGridView antes de agregar nuevos datos
                            dataGridViewProductos.Rows.Clear();

                            // Leer los datos y agregarlos al DataGridView
                            while (reader.Read())
                            {
                                // Agregar las filas con los valores obtenidos
                                dataGridViewProductos.Rows.Add(
                                    reader["IdProducto"].ToString(), // Agregar ID del producto
                                    reader["Nombre"].ToString(),
                                    reader["Precio"].ToString(),
                                    reader["Stock"].ToString(),
                                    reader["Categoria"].ToString(), // Nombre de la categoría
                                    reader["Proveedor"].ToString() // Nombre del proveedor
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar productos: " + ex.Message);
            }
        }

        private void LlenarComboBoxCategorias()
        {
            string query = "SELECT IdCategoria, Nombre FROM Categorias";
            using (SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    comboBoxCategoria.Items.Add(new ComboBoxItem { Text = reader["Nombre"].ToString(), Value = Convert.ToInt32(reader["IdCategoria"]) });
                }
            }
        }

        private void LlenarComboBoxProveedores()
        {
            string query = "SELECT IdProveedor, Nombre FROM Proveedores";
            using (SqlConnection connection = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    comboBoxProveedores.Items.Add(new ComboBoxItem { Text = reader["Nombre"].ToString(), Value = Convert.ToInt32(reader["IdProveedor"]) });
                }
            }
        }
        private void Consultar_Reportes_Load(object sender, EventArgs e)
        {
            LlenarComboBoxCategorias();
            LlenarComboBoxProveedores();
            GenerarReporteStockBajo();

        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {



            // Obtiene las selecciones de los ComboBox
            string categoriaSeleccionada = comboBoxCategoria.SelectedItem?.ToString(); // Asegúrate de que este comboBox contenga el nombre de la categoría
            string proveedorSeleccionado = comboBoxProveedores.SelectedItem?.ToString(); // Asegúrate de que este comboBox contenga el nombre del proveedor

            try
            {
                // Limpia el DataGridView antes de llenar
                dataGridViewProductos.DataSource = null; // Limpia la fuente de datos actual
                dataGridViewProductos.Columns.Clear(); // Limpia las columnas actuales

                // Configura las columnas del DataGridView
                dataGridViewProductos.AutoGenerateColumns = false; // No generar automáticamente las columnas
                dataGridViewProductos.Columns.Add("IdProducto", "ID Producto");
                dataGridViewProductos.Columns.Add("Nombre", "Nombre");
                dataGridViewProductos.Columns.Add("Precio", "Precio");
                dataGridViewProductos.Columns.Add("Stock", "Stock");
                dataGridViewProductos.Columns.Add("Categoria", "Categoría");
                dataGridViewProductos.Columns.Add("Proveedor", "Proveedor");

                // Crea la consulta SQL
                string query = "SELECT * FROM Productos WHERE 1=1"; // Condición inicial

                // Agrega condiciones a la consulta
                if (!string.IsNullOrEmpty(categoriaSeleccionada))
                {
                    query += " AND IdCategoria = (SELECT IdCategoria FROM Categorias WHERE Nombre = @NombreCategoria)";
                }

                if (!string.IsNullOrEmpty(proveedorSeleccionado))
                {
                    query += " AND IdProveedor = (SELECT IdProveedor FROM Proveedores WHERE Nombre = @NombreProveedor)";
                }

                using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);

                    // Asigna los parámetros si corresponden
                    if (!string.IsNullOrEmpty(categoriaSeleccionada))
                    {
                        cmd.Parameters.AddWithValue("@NombreCategoria", categoriaSeleccionada);
                    }

                    if (!string.IsNullOrEmpty(proveedorSeleccionado))
                    {
                        cmd.Parameters.AddWithValue("@NombreProveedor", proveedorSeleccionado);
                    }

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Limpia el DataGridView antes de agregar nuevos datos
                    dataGridViewProductos.Rows.Clear();

                    // Leer los datos y agregarlos al DataGridView
                    while (reader.Read())
                    {
                        dataGridViewProductos.Rows.Add(
                            reader["IdProducto"].ToString(),
                            reader["Nombre"].ToString(),
                            reader["Precio"].ToString(),
                            reader["Stock"].ToString(),
                            reader["IdCategoria"].ToString(), // Aquí puedes cambiarlo a la categoría si tienes un método para obtener su nombre
                            reader["IdProveedor"].ToString() // Aquí puedes cambiarlo a la proveedor si tienes un método para obtener su nombre
                        );
                    }

                    if (dataGridViewProductos.Rows.Count == 0)
                    {
                        MessageBox.Show("No se encontraron productos que coincidan con los criterios.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al filtrar productos: " + ex.Message);
            }

           
        }




        // Método para llenar el DataGridView de stock bajo
        private void GenerarReporteStockBajo()
        {
            try
            {

                if (dataGridViewStockBajo.Columns.Count == 0)
                {
                    dataGridViewStockBajo.Columns.Add("Nombre", "Nombre");
                    dataGridViewStockBajo.Columns.Add("Precio", "Precio");
                    dataGridViewStockBajo.Columns.Add("Stock", "Stock");
                    dataGridViewStockBajo.Columns.Add("Categoria", "Categoría"); // Cambiado de IdCategoria a Categoria
                    dataGridViewStockBajo.Columns.Add("Proveedor", "Proveedor"); // Cambiado de IdProveedor a Proveedor
                }

                // Abrir la conexión
                using (SqlConnection conn = new SqlConnection("Server = localhost\\SQLEXPRESS; Database = InventarioDB; Trusted_Connection = True;"))
                {
                    conn.Open();

                    // Consulta SQL para obtener los productos con stock menor a 10, con JOIN para obtener los nombres
                    string query = @"
                SELECT p.Nombre, p.Precio, p.Stock, c.Nombre AS Categoria, pr.Nombre AS Proveedor 
                FROM Productos p
                INNER JOIN Categorias c ON p.IdCategoria = c.IdCategoria
                INNER JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor
                WHERE p.Stock < 10";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Limpiar el DataGridView antes de agregar nuevos datos
                            dataGridViewStockBajo.Rows.Clear();

                            // Leer los datos y agregarlos al DataGridView
                            while (reader.Read())
                            {
                                // Agregar las filas con los valores obtenidos
                                dataGridViewStockBajo.Rows.Add(
                                    reader["Nombre"].ToString(),
                                    reader["Precio"].ToString(),
                                    reader["Stock"].ToString(),
                                    reader["Categoria"].ToString(), // Nombre de la categoría
                                    reader["Proveedor"].ToString() // Nombre del proveedor
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al generar el reporte de stock bajo: " + ex.Message);
            }
        }

        private void btnReporteStockBajo_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnRestaurar_Click(object sender, EventArgs e)
        {
            CargarProductos();
        }
    }
}

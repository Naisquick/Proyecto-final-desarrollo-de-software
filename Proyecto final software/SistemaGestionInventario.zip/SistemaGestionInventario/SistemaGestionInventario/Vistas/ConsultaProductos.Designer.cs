﻿namespace SistemaGestionInventario.Vistas
{
    partial class Consultar_Reportes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBoxProveedores = new ComboBox();
            comboBoxCategoria = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            btnFiltrar = new Button();
            dataGridViewProductos = new DataGridView();
            dataGridViewStockBajo = new DataGridView();
            label3 = new Label();
            btnRestaurar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewProductos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStockBajo).BeginInit();
            SuspendLayout();
            // 
            // comboBoxProveedores
            // 
            comboBoxProveedores.FormattingEnabled = true;
            comboBoxProveedores.Location = new Point(481, 86);
            comboBoxProveedores.Name = "comboBoxProveedores";
            comboBoxProveedores.Size = new Size(121, 23);
            comboBoxProveedores.TabIndex = 0;
            // 
            // comboBoxCategoria
            // 
            comboBoxCategoria.FormattingEnabled = true;
            comboBoxCategoria.Location = new Point(132, 86);
            comboBoxCategoria.Name = "comboBoxCategoria";
            comboBoxCategoria.Size = new Size(121, 23);
            comboBoxCategoria.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(164, 52);
            label1.Name = "label1";
            label1.Size = new Size(58, 15);
            label1.TabIndex = 2;
            label1.Text = "Categoria";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(504, 50);
            label2.Name = "label2";
            label2.Size = new Size(61, 15);
            label2.TabIndex = 3;
            label2.Text = "Proveedor";
            // 
            // btnFiltrar
            // 
            btnFiltrar.Location = new Point(327, 128);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(75, 23);
            btnFiltrar.TabIndex = 4;
            btnFiltrar.Text = "Filtrar";
            btnFiltrar.UseVisualStyleBackColor = true;
            btnFiltrar.Click += btnFiltrar_Click;
            // 
            // dataGridViewProductos
            // 
            dataGridViewProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewProductos.Location = new Point(95, 203);
            dataGridViewProductos.Name = "dataGridViewProductos";
            dataGridViewProductos.Size = new Size(507, 209);
            dataGridViewProductos.TabIndex = 5;
            // 
            // dataGridViewStockBajo
            // 
            dataGridViewStockBajo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewStockBajo.Location = new Point(641, 203);
            dataGridViewStockBajo.Name = "dataGridViewStockBajo";
            dataGridViewStockBajo.Size = new Size(470, 209);
            dataGridViewStockBajo.TabIndex = 7;
            dataGridViewStockBajo.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(802, 170);
            label3.Name = "label3";
            label3.Size = new Size(135, 15);
            label3.TabIndex = 8;
            label3.Text = "Productos de Stock bajo";
            label3.Click += label3_Click;
            // 
            // btnRestaurar
            // 
            btnRestaurar.Location = new Point(308, 418);
            btnRestaurar.Name = "btnRestaurar";
            btnRestaurar.Size = new Size(75, 23);
            btnRestaurar.TabIndex = 9;
            btnRestaurar.Text = "Restaurar";
            btnRestaurar.UseVisualStyleBackColor = true;
            btnRestaurar.Click += btnRestaurar_Click;
            // 
            // Consultar_Reportes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1142, 639);
            Controls.Add(btnRestaurar);
            Controls.Add(label3);
            Controls.Add(dataGridViewStockBajo);
            Controls.Add(dataGridViewProductos);
            Controls.Add(btnFiltrar);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(comboBoxCategoria);
            Controls.Add(comboBoxProveedores);
            Name = "Consultar_Reportes";
            Text = "Consultar_Reportes";
            Load += Consultar_Reportes_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewProductos).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStockBajo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBoxProveedores;
        private ComboBox comboBoxCategoria;
        private Label label1;
        private Label label2;
        private Button btnFiltrar;
        private DataGridView dataGridViewProductos;
        private DataGridView dataGridViewStockBajo;
        private Label label3;
        private Button btnRestaurar;
    }
}
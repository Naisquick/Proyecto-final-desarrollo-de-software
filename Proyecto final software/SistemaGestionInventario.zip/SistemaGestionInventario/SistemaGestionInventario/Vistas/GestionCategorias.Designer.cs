﻿namespace SistemaGestionInventario.Vistas
{
    partial class GestionCategorias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtNombreCategoria = new TextBox();
            txtDescripcionCategoria = new TextBox();
            label2 = new Label();
            dataGridViewCategorias = new DataGridView();
            button1 = new Button();
            btnAgregarCategoria = new Button();
            button3 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCategorias).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 36);
            label1.Name = "label1";
            label1.Size = new Size(131, 15);
            label1.TabIndex = 0;
            label1.Text = "Nombre de la categoria";
            // 
            // txtNombreCategoria
            // 
            txtNombreCategoria.Location = new Point(32, 65);
            txtNombreCategoria.Name = "txtNombreCategoria";
            txtNombreCategoria.Size = new Size(100, 23);
            txtNombreCategoria.TabIndex = 1;
            // 
            // txtDescripcionCategoria
            // 
            txtDescripcionCategoria.Location = new Point(240, 65);
            txtDescripcionCategoria.Name = "txtDescripcionCategoria";
            txtDescripcionCategoria.Size = new Size(100, 23);
            txtDescripcionCategoria.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(240, 36);
            label2.Name = "label2";
            label2.Size = new Size(69, 15);
            label2.TabIndex = 2;
            label2.Text = "Descripcion";
            // 
            // dataGridViewCategorias
            // 
            dataGridViewCategorias.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCategorias.Location = new Point(32, 109);
            dataGridViewCategorias.Name = "dataGridViewCategorias";
            dataGridViewCategorias.Size = new Size(346, 178);
            dataGridViewCategorias.TabIndex = 4;
            // 
            // button1
            // 
            button1.Location = new Point(150, 293);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 5;
            button1.Text = "Editar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnAgregarCategoria
            // 
            btnAgregarCategoria.Location = new Point(69, 293);
            btnAgregarCategoria.Name = "btnAgregarCategoria";
            btnAgregarCategoria.Size = new Size(75, 23);
            btnAgregarCategoria.TabIndex = 6;
            btnAgregarCategoria.Text = "Agregar";
            btnAgregarCategoria.UseVisualStyleBackColor = true;
            btnAgregarCategoria.Click += btnAgregarCategoria_Click;
            // 
            // button3
            // 
            button3.Location = new Point(231, 293);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 7;
            button3.Text = "Eliminar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // GestionCategorias
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(btnAgregarCategoria);
            Controls.Add(button1);
            Controls.Add(dataGridViewCategorias);
            Controls.Add(txtDescripcionCategoria);
            Controls.Add(label2);
            Controls.Add(txtNombreCategoria);
            Controls.Add(label1);
            Name = "GestionCategorias";
            Text = "GestionCategorias";
            Load += GestionCategorias_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewCategorias).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNombreCategoria;
        private TextBox txtDescripcionCategoria;
        private Label label2;
        private DataGridView dataGridViewCategorias;
        private Button button1;
        private Button btnAgregarCategoria;
        private Button button3;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaGestionInventario.Vistas
{
    public partial class GestionCategorias : Form
    {
        public GestionCategorias()
        {
            InitializeComponent();
            dataGridViewCategorias.SelectionChanged += dataGridViewCategorias_SelectionChanged;

        }

        private void GestionCategorias_Load(object sender, EventArgs e)
        {
            CargarCategorias();
        }

        private void CargarCategorias()
        {
            using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Categorias", conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewCategorias.DataSource = dt;
            }
        }

        private void btnAgregarCategoria_Click(object sender, EventArgs e)
        {
            // Verificar que los campos no estén vacíos
            if (string.IsNullOrWhiteSpace(txtNombreCategoria.Text) || string.IsNullOrWhiteSpace(txtDescripcionCategoria.Text))
            {
                MessageBox.Show("Por favor ingresa un nombre y una descripción para la categoría.");
                return;
            }

            using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Categorias (Nombre, Descripcion) VALUES (@nombre, @descripcion)", conn);
                cmd.Parameters.AddWithValue("@nombre", txtNombreCategoria.Text);
                cmd.Parameters.AddWithValue("@descripcion", txtDescripcionCategoria.Text);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Categoría agregada exitosamente.");
                    txtNombreCategoria.Clear();
                    txtDescripcionCategoria.Clear(); // Limpiar el TextBox de descripción
                    CargarCategorias(); // Recargar categorías
                }
                else
                {
                    MessageBox.Show("Error al agregar la categoría.");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Verificar que se haya seleccionado una categoría en el DataGridView
            if (dataGridViewCategorias.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor selecciona una categoría para eliminar.");
                return;
            }

            // Obtener el ID de la categoría seleccionada
            int categoriaId = Convert.ToInt32(dataGridViewCategorias.SelectedRows[0].Cells["IdCategoria"].Value);

            // Confirmar la acción de eliminación
            var confirmResult = MessageBox.Show("¿Estás seguro de que deseas eliminar esta categoría?",
                                                 "Confirmar eliminación",
                                                 MessageBoxButtons.YesNo,
                                                 MessageBoxIcon.Warning);

            if (confirmResult == DialogResult.Yes)
            {
                using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Categorias WHERE IdCategoria = @id", conn);
                    cmd.Parameters.AddWithValue("@id", categoriaId);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Categoría eliminada exitosamente.");
                        CargarCategorias(); // Recargar categorías
                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar la categoría.");
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Verificar que se haya seleccionado una categoría en el DataGridView
            if (dataGridViewCategorias.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor selecciona una categoría para actualizar.");
                return;
            }

            // Obtener el ID de la categoría seleccionada
            int categoriaId = Convert.ToInt32(dataGridViewCategorias.SelectedRows[0].Cells["IdCategoria"].Value);

            // Obtener el nuevo nombre y descripción desde los TextBox correspondientes
            string nuevoNombre = txtNombreCategoria.Text;
            string nuevaDescripcion = txtDescripcionCategoria.Text;

            //Validar que los campos no estén vacíos
            if (string.IsNullOrWhiteSpace(nuevoNombre) || string.IsNullOrWhiteSpace(nuevaDescripcion))
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            // Actualizar la categoría en la base de datos
            using (SqlConnection conn = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=InventarioDB;Trusted_Connection=True;"))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("UPDATE Categorias SET Nombre = @nombre, Descripcion = @descripcion WHERE IdCategoria = @id", conn);
                cmd.Parameters.AddWithValue("@nombre", nuevoNombre);
                cmd.Parameters.AddWithValue("@descripcion", nuevaDescripcion);
                cmd.Parameters.AddWithValue("@id", categoriaId);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Categoría actualizada exitosamente.");
                    CargarCategorias(); // Recargar categorías
                }
                else
                {
                    MessageBox.Show("Error al actualizar la categoría.");
                }
            }
        }

        private void dataGridViewCategorias_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewCategorias.SelectedRows.Count > 0)
            {
                // Obtén la fila seleccionada
                var selectedRow = dataGridViewCategorias.SelectedRows[0];

                // Asigna el nombre y la descripción a los TextBox
                txtNombreCategoria.Text = selectedRow.Cells["Nombre"].Value.ToString();
                txtDescripcionCategoria.Text = selectedRow.Cells["Descripcion"].Value.ToString();
            }
        }

    }

}
        

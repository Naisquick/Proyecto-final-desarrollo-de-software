﻿using System;
using System.Data.SqlClient;
using SistemaGestionInventario.Modelos;
using System.Configuration;

namespace SistemaGestionInventario.Controladores
{
    public class ProductoController
    {
        public void AgregarProducto(Producto producto)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["InventarioDB"].ConnectionString))
            {
                conn.Open();
                string query = "INSERT INTO Productos (Nombre, CategoriaId, Precio, Existencia, ProveedorId) VALUES (@Nombre, @CategoriaId, @Precio, @Existencia, @ProveedorId)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Nombre", producto.Nombre);
                    cmd.Parameters.AddWithValue("@CategoriaId", producto.Categoria.IdCategoria);
                    cmd.Parameters.AddWithValue("@Precio", producto.Precio);
                    cmd.Parameters.AddWithValue("@Existencia", producto.Existencia);
                    cmd.Parameters.AddWithValue("@ProveedorId", producto.Proveedor.IdProveedor);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}


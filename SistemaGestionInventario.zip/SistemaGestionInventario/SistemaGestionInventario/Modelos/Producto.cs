﻿namespace SistemaGestionInventario.Modelos
{
    public class Producto
    {
        public int CodigoProducto { get; set; }
        public string Nombre { get; set; }
        public Categoria Categoria { get; set; }
        public decimal Precio { get; set; }
        public int Existencia { get; set; }
        public Proveedor Proveedor { get; set; }
    }
}

